package sensorReaders;

public interface BluetoothDeviceFoundListener {
    void onDeviceFound(BluetoothSignalMetadata signalData);
}
