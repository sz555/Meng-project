package sensorReaders;

public interface DisplaySensorValuesInterface {
    void execute(float[] values);
}
