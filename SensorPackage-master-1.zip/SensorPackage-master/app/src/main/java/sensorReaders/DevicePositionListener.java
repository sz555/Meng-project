package sensorReaders;

public interface DevicePositionListener {
    void onPosition(DeviceCoord position);
}
